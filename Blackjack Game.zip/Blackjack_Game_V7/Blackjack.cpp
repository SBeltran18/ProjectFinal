#include "Blackjack.h"

// Constructor to initialize the game
Blackjack::Blackjack() : gameOver(false), roundOver(false) {
    // Game setup
    bet.setBetAmount(0);
    dealer.reset();
    player.reset();
    deck.shuffle();
}

// Starts a new round of Blackjack
void Blackjack::startNewRound() {
    if (gameOver) {
        std::cout << "Game over. Please start a new game.\n";
        return;
    }

    roundOver = false;
    dealer.reset();
    player.reset();
    bet.setBetAmount(0);

    placeBet();
    dealInitialCards();
}

// Prompts the player to make a bet and starts the round
void Blackjack::placeBet() {
    int betAmount;
    std::cout << "Enter your bet amount: $";
    std::cin >> betAmount;
    bet.setBetAmount(betAmount);

    std::cout << "Bet of $" << betAmount << " placed.\n";
}

// Deals the initial cards to both player and dealer
void Blackjack::dealInitialCards() {
    dealer.dealInitialHand(player.getHand());

    std::cout << "Dealer's hand: ";
    dealer.displayHand(false); // Display dealer's hand, hiding second card
    std::cout << "\n";

    std::cout << "Player's hand: ";
    player.displayHand();
    std::cout << "\n";

    // Check for initial blackjack
    if (dealer.checkBlackjack()) {
        dealer.displayHand(true);
        std::cout << "Dealer has Blackjack!\n";
        roundOver = true;
        determineWinner();
    } else if (player.checkBlackjack()) {
        player.displayHand();
        std::cout << "Player has Blackjack!\n";
        roundOver = true;
        determineWinner();
    }
}

// Plays the player's turn where they can hit or stand
void Blackjack::playerTurn() {
    while (true) {
        char choice;
        std::cout << "Do you want to (h)it or (s)tand? ";
        std::cin >> choice;

        if (choice == 'h' || choice == 'H') {
            Card card = deck.drawCard();
            player.receiveCard(card);
            player.displayHand();
            std::cout << "\n";

            if (player.checkBust()) {
                std::cout << "Player busts!\n";
                roundOver = true;
                break;
            }
        } else if (choice == 's' || choice == 'S') {
            std::cout << "Player stands.\n";
            break;
        } else {
            std::cout << "Invalid input, please choose 'h' or 's'.\n";
        }
    }
}

// Plays the dealer's turn where they follow Blackjack rules
void Blackjack::dealerTurn() {
    dealer.displayHand(true);
    while (dealer.calculateHandValue() < 17) {
        std::cout << "Dealer hits.\n";
        Card card = deck.drawCard();
        dealer.receiveCard(card);
        dealer.displayHand(true);
        std::cout << "\n";

        if (dealer.checkBust()) {
            std::cout << "Dealer busts!\n";
            roundOver = true;
            break;
        }
    }

    if (!dealer.checkBust()) {
        std::cout << "Dealer stands.\n";
    }
}

// Determines the winner of the round
void Blackjack::determineWinner() {
    if (player.checkBust()) {
        std::cout << "Player loses.\n";
    } else if (dealer.checkBust()) {
        std::cout << "Player wins!\n";
    } else if (player.calculateHandValue() > dealer.calculateHandValue()) {
        std::cout << "Player wins!\n";
    } else if (player.calculateHandValue() < dealer.calculateHandValue()) {
        std::cout << "Dealer wins.\n";
    } else {
        std::cout << "It's a tie!\n";
    }

    roundOver = true;
}

// Displays the current status of the game
void Blackjack::displayGameStatus() const {
    std::cout << "Game Status: \n";
    std::cout << "Player's Hand: ";
    player.displayHand();
    std::cout << "Dealer's Hand: ";
    dealer.displayHand(true);
}

// Ends the game and shows the final result
void Blackjack::endGame() {
    std::cout << "Game over. Final results:\n";
    determineWinner();
    gameOver = true;
}

// Resets the game for a new round
void Blackjack::resetGame() {
    dealer.reset();
    player.reset();
    deck.shuffle();
    gameOver = false;
    roundOver = false;
    std::cout << "Game has been reset. Start a new round.\n";
}

// Returns true if the game is over
bool Blackjack::isGameOver() const {
    return gameOver;
}

// Returns true if the round is over
bool Blackjack::isRoundOver() const {
    return roundOver;
}

// Displays the current bet amount
void Blackjack::displayBetAmount() const {
    std::cout << "Current bet amount: $" << bet.getBetAmount() << "\n";
}
