#ifndef BLACKJACK_H
#define BLACKJACK_H

#include <iostream>
#include <vector>
#include "Card.h"
#include "Deck.h"
#include "Player.h"
#include "Dealer.h"
#include "Bet.h"

class Blackjack {
private:
    Player player;                 // The player object
    Dealer dealer;                 // The dealer object
    Bet bet;                       // The bet object
    Deck deck;                     // The deck of cards
    bool gameOver;                 // Flag indicating if the game is over
    bool roundOver;                // Flag indicating if the round is over

public:
    // Constructor to initialize the Blackjack game
    Blackjack();

    // Starts a new round of Blackjack
    void startNewRound();

    // Prompts the player to make a bet and starts the round
    void placeBet();

    // Deals the initial cards to both player and dealer
    void dealInitialCards();

    // Plays the player's turn where they can hit or stand
    void playerTurn();

    // Plays the dealer's turn where they follow Blackjack rules
    void dealerTurn();

    // Determines the winner of the round
    void determineWinner();

    // Displays the current status of the game
    void displayGameStatus() const;

    // Ends the game and shows the final result
    void endGame();

    // Resets the game for a new round
    void resetGame();

    // Returns true if the game is over
    bool isGameOver() const;

    // Returns true if the round is over
    bool isRoundOver() const;

    // Displays the current bet amount
    void displayBetAmount() const;
};

#endif // BLACKJACK_H
