#ifndef BET_H
#define BET_H

#include <iostream>
#include <limits>
#include <string>

// This class handles the player's bet in a Blackjack game
class Bet {
private:
    int amount; // Stores the current bet amount
    int minBet; // Minimum bet allowed
    int maxBet; // Maximum bet allowed
    std::string betName; // Optional name for the bet (e.g., "Initial", "Double", etc.)
    
    // Private method to check if the bet is within allowed range
    bool isWithinRange(int bet) const {
        return (bet >= minBet && bet <= maxBet);
    }

public:
    // Constructor to initialize the bet, with optional min and max bet limits
    Bet(int min = 5, int max = 1000, std::string name = "Default Bet");

    // Set the bet amount, validates it
    void setBetAmount(int bet);

    // Get the current bet amount
    int getBetAmount() const;

    // Resets the bet amount to 0
    void resetBet();

    // Validate if the bet amount is greater than 0 and within range
    bool isValidBet() const;

    // Displays the current bet amount
    void displayBet() const;

    // Method to change the bet limits (e.g., for high-stakes rounds)
    void changeBetLimits(int newMin, int newMax);

    // Method to modify the bet type (optional feature)
    void setBetType(const std::string& type);

    // Method to check if the player has enough funds for the bet (stub for future implementation)
    bool hasEnoughFunds(int playerFunds) const;

    // Prints detailed info about the bet
    void displayBetDetails() const;

    // Get the minimum allowed bet
    int getMinBet() const;

    // Get the maximum allowed bet
    int getMaxBet() const;

    // Additional validation method to check if the bet is too high
    bool isTooHigh(int playerFunds) const;

    // Overloaded comparison operator to compare two bets
    bool operator==(const Bet& other) const;
};

#endif // BET_H
