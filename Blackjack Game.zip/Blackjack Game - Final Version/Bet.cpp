#include "Bet.h"

// Constructor initializes the bet amount to 0 by default, with optional min/max bet limits
Bet::Bet(int min, int max, std::string name) : minBet(min), maxBet(max), amount(0), betName(name) {
    if (minBet <= 0) {
        minBet = 5;  // Default to 5 if invalid min bet
    }
    if (maxBet <= minBet) {
        maxBet = 1000; // Default max bet if invalid
    }
    std::cout << "Bet initialized: " << betName << " with min bet: $" << minBet << " and max bet: $" << maxBet << std::endl;
}

// Sets the bet amount, ensuring it is within the allowed range
void Bet::setBetAmount(int bet) {
    if (bet <= 0) {
        std::cerr << "Error: Bet amount must be positive." << std::endl;
    } else if (isWithinRange(bet)) {
        amount = bet;
        std::cout << "Bet of $" << amount << " set successfully!" << std::endl;
    } else {
        std::cerr << "Error: Bet amount must be between $" << minBet << " and $" << maxBet << std::endl;
    }
}

// Returns the current bet amount
int Bet::getBetAmount() const {
    return amount;
}

// Resets the bet to 0
void Bet::resetBet() {
    amount = 0;
    std::cout << "Bet has been reset to $0." << std::endl;
}

// Checks if the bet is valid (positive and within range)
bool Bet::isValidBet() const {
    return (amount > 0 && isWithinRange(amount));
}

// Displays the current bet amount
void Bet::displayBet() const {
    std::cout << "Current bet: $" << amount << std::endl;
}

// Changes the bet limits (min and max bet)
void Bet::changeBetLimits(int newMin, int newMax) {
    if (newMin > 0 && newMax > newMin) {
        minBet = newMin;
        maxBet = newMax;
        std::cout << "Bet limits changed to min: $" << minBet << ", max: $" << maxBet << std::endl;
    } else {
        std::cerr << "Invalid bet limits. Min must be greater than 0 and less than max." << std::endl;
    }
}

// Sets the bet type (for example, different bet types like "Double Down" or "Insurance")
void Bet::setBetType(const std::string& type) {
    betName = type;
    std::cout << "Bet type set to: " << betName << std::endl;
}

// Check if the player has enough funds to place the bet
bool Bet::hasEnoughFunds(int playerFunds) const {
    return playerFunds >= amount;
}

// Displays detailed information about the bet
void Bet::displayBetDetails() const {
    std::cout << "Bet Details: " << std::endl;
    std::cout << "Type: " << betName << std::endl;
    std::cout << "Amount: $" << amount << std::endl;
    std::cout << "Min Bet: $" << minBet << std::endl;
    std::cout << "Max Bet: $" << maxBet << std::endl;
}

// Returns the minimum bet allowed
int Bet::getMinBet() const {
    return minBet;
}

// Returns the maximum bet allowed
int Bet::getMaxBet() const {
    return maxBet;
}

// Checks if the bet is too high for the player's current funds
bool Bet::isTooHigh(int playerFunds) const {
    return amount > playerFunds;
}

// Comparison operator for two bet objects (to check if their amounts are equal)
bool Bet::operator==(const Bet& other) const {
    return amount == other.amount;
}
