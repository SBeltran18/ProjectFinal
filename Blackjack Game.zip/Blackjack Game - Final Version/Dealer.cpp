#include "Dealer.h"

// Constructor initializes the dealer with a new deck and resets flags
Dealer::Dealer() : isBusted(false), hasBlackjack(false), isStanding(false) {
    shuffleDeck();  // Shuffle the deck when the dealer is created
}

// Resets the dealer's hand and status for a new round
void Dealer::reset() {
    hand.clear();
    isBusted = false;
    hasBlackjack = false;
    isStanding = false;
    shuffleDeck();  // Shuffle the deck again
}

// Deals the first two cards to the dealer and the player
void Dealer::dealInitialHand(std::vector<Card>& playerHand) {
    playerHand.push_back(dealCard());
    playerHand.push_back(dealCard());

    hand.push_back(dealCard());
    hand.push_back(dealCard());
}

// Adds a card to the dealer's hand
void Dealer::receiveCard(const Card& card) {
    hand.push_back(card);
}

// Displays the dealer's hand, but hides the second card initially
void Dealer::displayHand(bool showSecondCard) const {
    std::cout << "Dealer's Hand: ";
    if (showSecondCard) {
        for (const Card& card : hand) {
            card.displayCard();
        }
    } else {
        hand[0].displayCard();
        std::cout << " [Hidden Card]" << std::endl;
    }
}

// Calculates the total value of the dealer's hand
int Dealer::calculateHandValue() const {
    int totalValue = 0;
    int aceCount = 0;

    for (const Card& card : hand) {
        totalValue += card.getValue();
        if (card.getRank() == "Ace") {
            aceCount++;
        }
    }

    // Adjust for Aces (Ace can be 1 or 11)
    while (totalValue <= 11 && aceCount > 0) {
        totalValue += 10;  // Convert Ace to 11 if it doesn't bust the hand
        aceCount--;
    }

    return totalValue;
}

// Checks if the dealer has busted (hand value > 21)
bool Dealer::checkBust() const {
    return (calculateHandValue() > 21);
}

// Checks if the dealer has blackjack (Ace + 10/Face card)
bool Dealer::checkBlackjack() const {
    return (hand.size() == 2 && calculateHandValue() == 21);
}

// The dealer will continue to draw cards until their hand value is 17 or more
void Dealer::playTurn() {
    while (calculateHandValue() < 17) {
        std::cout << "Dealer draws a card." << std::endl;
        receiveCard(dealCard());
    }

    isStanding = true;
    std::cout << "Dealer stands with a hand value of " << calculateHandValue() << std::endl;
}

// Returns true if the dealer is busted
bool Dealer::isDealerBusted() const {
    return isBusted;
}

// Returns true if the dealer has blackjack
bool Dealer::isDealerBlackjack() const {
    return hasBlackjack;
}

// Returns true if the dealer is standing
bool Dealer::isDealerStanding() const {
    return isStanding;
}

// Returns the dealer's current hand
std::vector<Card>& Dealer::getHand() {
    return hand;
}

// Shuffles the deck of cards before starting the game
void Dealer::shuffleDeck() {
    deck.shuffle();
}

// Deals a card from the deck
Card Dealer::dealCard() {
    return deck.drawCard();
}
