#ifndef DECK_H
#define DECK_H

#include "Card.h"
#include <vector>
#include <algorithm>
#include <iostream>

class Deck {
private:
    std::vector<Card> deck;  // Holds the 52 cards
    int currentCardIndex;    // Keeps track of the next card to be dealt

    // Shuffles the deck using rand()
    void shuffleDeck();

public:
    // Constructor to initialize the deck and shuffle it
    Deck();

    // Initializes a deck with 52 cards
    void initializeDeck();

    // Deals one card from the deck
    Card dealCard();

    // Returns the number of cards remaining in the deck
    int cardsRemaining() const;

    // Resets and reshuffles the deck
    void resetDeck();

    // Displays the current state of the deck (for debugging)
    void displayDeck() const;

    // Checks if the deck is empty
    bool isEmpty() const;

    // Reshuffles the deck if needed (when it's empty)
    void reshuffleDeck();

    // Friend function to output the deck status
    friend std::ostream& operator<<(std::ostream& os, const Deck& deck);
};

#endif // DECK_H
