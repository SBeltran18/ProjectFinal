#include <iostream>
#include "Blackjack.h"
#include "Menu.h"

int main() {
    // Create a Blackjack game object
    Blackjack blackjackGame;

    // Create a Menu object, passing the Blackjack game object to it
    Menu menu(blackjackGame);

    // Display the main menu and start the game loop
    while (true) {
        menu.displayMainMenu();         // Show the menu
        menu.handleMainMenuInput();     // Handle user input
    }

    return 0;  // In case the loop exits, return 0 (though the loop never exits unless the game ends)
}
