#include "Player.h"
#include "Card.h"
#include <iostream>

// Default constructor
Player::Player(std::string playerName, int initialFunds)
    : name(playerName), funds(initialFunds), score(0) {}

// Copy constructor
Player::Player(const Player &other)
    : name(other.name), funds(other.funds), hand(other.hand), score(other.score) {}

// Destructor
Player::~Player() {}

// Getter for name
std::string Player::getName() const {
    return name;
}

// Setter for name
void Player::setName(const std::string& playerName) {
    name = playerName;
}

// Getter for funds
int Player::getFunds() const {
    return funds;
}

// Setter for funds
void Player::setFunds(int newFunds) {
    funds = newFunds;
}

// Getter for score
int Player::getScore() const {
    return score;
}

// Setter for score
void Player::setScore(int newScore) {
    score = newScore;
}

// Add card to player's hand and update score
void Player::addCardToHand(const Card &card) {
    hand.push_back(card);
    updateScore();
}

// Remove card from player's hand and update score
void Player::removeCardFromHand(const Card &card) {
    for (auto it = hand.begin(); it != hand.end(); ++it) {
        if (*it == card) {
            hand.erase(it);
            break;
        }
    }
    updateScore();
}

// Show player's hand
void Player::showHand(bool revealAll) const {
    if (hand.empty()) {
        std::cout << name << " has no cards." << std::endl;
        return;
    }

    std::cout << name << "'s hand: ";
    for (size_t i = 0; i < hand.size(); ++i) {
        if (revealAll || i != 0) {  // Only hide the first card if revealAll is false
            hand[i].displayCard();   // Assuming Card::displayCard() exists
        } else {
            std::cout << "[Hidden] ";
        }
    }
    std::cout << "Score: " << score << std::endl;
}

// Reset player's hand and score
void Player::reset() {
    hand.clear();
    score = 0;
}

// Place a bet for the player
int Player::placeBet(int betAmount) {
    if (betAmount > funds) {
        std::cout << "You don't have enough funds!" << std::endl;
        return 0;
    } else {
        funds -= betAmount;
        return betAmount;
    }
}

// Win the bet, add winnings to player's funds
void Player::winBet(int betAmount) {
    funds += betAmount;
}

// Lose the bet, no money back
void Player::loseBet(int betAmount) {
    // No additional action needed, since bet is already subtracted
}

// Player stands
void Player::stand() {
    std::cout << name << " stands." << std::endl;
}

// Player hits, indicating the player draws another card
void Player::hit() {
    std::cout << name << " hits." << std::endl;
}

// Check if player has busted (score > 21)
bool Player::hasBusted() const {
    return score > 21;
}

// Check if player has Blackjack (score == 21)
bool Player::hasBlackjack() const {
    return score == 21 && hand.size() == 2;  // Blackjack is achieved with exactly 2 cards
}

// Update player's score based on the current hand
void Player::updateScore() {
    score = 0;
    for (const auto& card : hand) {
        score += card.getValue();  // Assuming Card::getValue() returns the card's value
    }
}

// Get the number of cards in the player's hand
size_t Player::getHandSize() const {
    return hand.size();
}

// Display player's status (name, funds, score)
void Player::displayStatus() const {
    std::cout << "Player: " << name << std::endl;
    std::cout << "Funds: $" << funds << std::endl;
    std::cout << "Score: " << score << std::endl;
}

// Display a summary of the player's hand
void Player::displayHandSummary() const {
    std::cout << name << "'s hand contains " << hand.size() << " cards:" << std::endl;
    for (const auto& card : hand) {
        card.displayCard();
    }
    std::cout << "Total score: " << score << std::endl;
}

// Check if player has enough funds to play
bool Player::canPlay() const {
    return funds > 0;
}

// Compare this player’s score to another player's score
int Player::compareScores(const Player &other) const {
    if (score > other.score) {
        return 1;  // This player has a higher score
    } else if (score < other.score) {
        return -1;  // The other player has a higher score
    } else {
        return 0;  // Scores are equal
    }
}

// Transfer funds from one player to another
void Player::transferFunds(Player &from, Player &to, int amount) {
    from.funds -= amount;
    to.funds += amount;
}

// Static method to create a default player (used for AI or dealer)
Player Player::createDefaultPlayer() {
    return Player("Dealer", 0);  // Dealer starts with no initial funds
}

// Display detailed player information
void Player::displayPlayerDetails() const {
    std::cout << "Name: " << name << std::endl;
    std::cout << "Funds: $" << funds << std::endl;
    std::cout << "Score: " << score << std::endl;
}

// Check if player has reached a specific score threshold
bool Player::hasReachedThreshold(int threshold) const {
    return score >= threshold;
}

// Check if the player is eligible for a bonus (e.g., Blackjack)
bool Player::isEligibleForBonus() const {
    return score == 21;  // Simple check for Blackjack eligibility
}

// Place a split bet if the player has two matching cards
bool Player::canSplit() const {
    return hand.size() == 2 && hand[0].getValue() == hand[1].getValue();
}

// Split the hand into two separate hands if the player can
void Player::splitHand() {
    if (canSplit()) {
        Card cardToMove = hand.back();
        hand.pop_back();
        std::vector<Card> newHand = { hand.back(), cardToMove }; // Create a new hand with one card
        hand.pop_back();
        // The player now has two hands to play
        std::cout << "Hand split into two hands!" << std::endl;
    } else {
        std::cout << "Cannot split hand." << std::endl;
    }
}
