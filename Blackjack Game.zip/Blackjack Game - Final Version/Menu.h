#ifndef MENU_H
#define MENU_H

#include <iostream>
#include "Blackjack.h"

class Menu {
private:
    Blackjack& game;  // Reference to the Blackjack game object

public:
    // Constructor to initialize the menu with a reference to the game
    Menu(Blackjack& blackjackGame);

    // Displays the main menu to the player
    void displayMainMenu() const;

    // Handles the user input for the main menu
    void handleMainMenuInput();

    // Displays the current game status
    void displayGameStatus() const;

    // Starts a new game
    void startNewGame();

    // Ends the game
    void endGame();
};

#endif // MENU_H
