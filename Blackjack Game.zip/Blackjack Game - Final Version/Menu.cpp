#include "Menu.h"

// Constructor that takes a reference to a Blackjack game object
Menu::Menu(Blackjack& blackjackGame) : game(blackjackGame) {}

// Displays the main menu to the player
void Menu::displayMainMenu() const {
    std::cout << "\nWelcome to Blackjack!\n";
    std::cout << "=======================\n";
    std::cout << "1. Start New Game\n";
    std::cout << "2. View Game Status\n";
    std::cout << "3. Exit\n";
    std::cout << "Please select an option (1-3): ";
}

// Handles the user input for the main menu
void Menu::handleMainMenuInput() {
    int choice;
    std::cin >> choice;

    switch (choice) {
        case 1:
            startNewGame();
            break;
        case 2:
            displayGameStatus();
            break;
        case 3:
            endGame();
            break;
        default:
            std::cout << "Invalid option. Please choose between 1 and 3.\n";
            handleMainMenuInput();
            break;
    }
}

// Displays the current game status
void Menu::displayGameStatus() const {
    if (game.isGameOver()) {
        std::cout << "Game over! No active game to show status.\n";
    } else {
        game.displayGameStatus();
    }
    displayMainMenu();  // After showing status, return to the main menu
    handleMainMenuInput();  // Wait for input again
}

// Starts a new game by resetting the game state
void Menu::startNewGame() {
    std::cout << "\nStarting a new game...\n";
    game.resetGame();  // Reset the game state
    game.startNewRound();  // Start a new round
    displayMainMenu();  // Show the main menu again
    handleMainMenuInput();  // Wait for input again
}

// Ends the game and exits the program
void Menu::endGame() {
    std::cout << "Thanks for playing! Exiting the game...\n";
    exit(0);  // Exit the program
}
