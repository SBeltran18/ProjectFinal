#ifndef CARD_H
#define CARD_H

#include <string>
#include <iostream>

enum class Suit { Hearts, Diamonds, Clubs, Spades };

class Card {
private:
    int value;      // The rank of the card (1-13)
    Suit suit;      // The suit of the card (Hearts, Diamonds, Clubs, Spades)
    std::string displayName; // A name to display the card (e.g., "Ace of Hearts")

public:
    // Default constructor (initializes the card to Ace of Hearts)
    Card();
    
    // Parameterized constructor
    Card(int value, Suit suit);

    // Getters for card properties
    int getValue() const;
    Suit getSuit() const;
    std::string getDisplayName() const;

    // Function to display the card's face (e.g., Ace of Hearts)
    void displayCard() const;

    // Function to determine if a card is a face card (Jack, Queen, King)
    bool isFaceCard() const;

    // Function to return the string representation of the card's suit
    std::string suitToString() const;

    // Function to return the string representation of the card's rank
    std::string rankToString() const;

    // Function to compare two cards (used for sorting or other comparisons)
    bool operator<(const Card& other) const;

    // Overload the equality operator for comparing cards
    bool operator==(const Card& other) const;

    // Function to reset the card to an uninitialized state
    void resetCard();
    
    // Function to get the color of the card
    std::string getColor() const;

    // Static function to return a description of the card class
    static std::string classDescription();

    // Overload the stream insertion operator to print the card
    friend std::ostream& operator<<(std::ostream& os, const Card& card);
};

#endif // CARD_H
