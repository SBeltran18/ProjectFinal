#include "Card.h"

// Default constructor: Initializes the card to Ace of Hearts
Card::Card() : value(1), suit(Suit::Hearts), displayName("Ace of Hearts") {}

// Parameterized constructor: Initializes the card with a given value and suit
Card::Card(int value, Suit suit) : value(value), suit(suit) {
    displayName = rankToString() + " of " + suitToString();
}

// Getter for the value (rank) of the card
int Card::getValue() const {
    return value;
}

// Getter for the suit of the card
Suit Card::getSuit() const {
    return suit;
}

// Getter for the display name of the card (e.g., "Ace of Hearts")
std::string Card::getDisplayName() const {
    return displayName;
}

// Display the card in a human-readable format
void Card::displayCard() const {
    std::cout << displayName << std::endl;
}

// Check if the card is a face card (Jack, Queen, King)
bool Card::isFaceCard() const {
    return value == 11 || value == 12 || value == 13;
}

// Return the string representation of the card's suit
std::string Card::suitToString() const {
    switch (suit) {
        case Suit::Hearts: return "Hearts";
        case Suit::Diamonds: return "Diamonds";
        case Suit::Clubs: return "Clubs";
        case Suit::Spades: return "Spades";
        default: return "Unknown";
    }
}

// Return the string representation of the card's rank
std::string Card::rankToString() const {
    switch (value) {
        case 1: return "Ace";
        case 11: return "Jack";
        case 12: return "Queen";
        case 13: return "King";
        default: return std::to_string(value);
    }
}

// Compare two cards for sorting or other purposes
bool Card::operator<(const Card& other) const {
    return value < other.value;
}

// Overload equality operator to compare cards
bool Card::operator==(const Card& other) const {
    return value == other.value && suit == other.suit;
}

// Reset the card to its default state (Ace of Hearts)
void Card::resetCard() {
    value = 1;
    suit = Suit::Hearts;
    displayName = "Ace of Hearts";
}

// Get the color of the card (red or black)
std::string Card::getColor() const {
    if (suit == Suit::Hearts || suit == Suit::Diamonds) {
        return "Red";
    } else {
        return "Black";
    }
}

// Static function to return a description of the card class
std::string Card::classDescription() {
    return "This is a class that represents a standard playing card, with a rank and suit.";
}

// Overload the stream insertion operator for printing a card
std::ostream& operator<<(std::ostream& os, const Card& card) {
    os << card.getDisplayName();
    return os;
}
