#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include <vector>
#include <iostream>
#include "Card.h"  // Make sure you include the Card class for hand management

class Player {
private:
    std::string name;                      // Player's name
    int funds;                             // Player's funds/money
    std::vector<Card> hand;                // Player's hand (cards they hold)
    int score;                             // Player's score (sum of card values)

public:
    // Default constructor with player name and initial funds
    Player(std::string playerName, int initialFunds = 1000)
        : name(playerName), funds(initialFunds), score(0) {}

    // Copy constructor
    Player(const Player &other)
        : name(other.name), funds(other.funds), hand(other.hand), score(other.score) {}

    // Destructor
    ~Player() {}

    // Getter and Setter for the player's name
    std::string getName() const { return name; }
    void setName(const std::string& playerName) { name = playerName; }

    // Getter and Setter for funds (Player's money)
    int getFunds() const { return funds; }
    void setFunds(int newFunds) { funds = newFunds; }

    // Getter and Setter for score (sum of card values)
    int getScore() const { return score; }
    void setScore(int newScore) { score = newScore; }

    // Add a card to the player's hand
    void addCardToHand(const Card &card) {
        hand.push_back(card);
        updateScore();
    }

    // Remove a card from the player's hand
    void removeCardFromHand(const Card &card) {
        // Find the card in the hand and remove it
        for (auto it = hand.begin(); it != hand.end(); ++it) {
            if (*it == card) {
                hand.erase(it);
                break;
            }
        }
        updateScore();
    }

    // Show the cards in the player's hand
    void showHand(bool revealAll = true) const {
        if (hand.empty()) {
            std::cout << name << " has no cards." << std::endl;
            return;
        }

        std::cout << name << "'s hand: ";
        for (const auto& card : hand) {
            if (revealAll || &card != &hand.front()) {
                card.displayCard();
            } else {
                std::cout << "[Hidden] ";
            }
        }
        std::cout << "Score: " << score << std::endl;
    }

    // Reset the player's hand and score
    void reset() {
        hand.clear();
        score = 0;
    }

    // Place a bet
    int placeBet(int betAmount) {
        if (betAmount > funds) {
            std::cout << "You don't have enough funds!" << std::endl;
            return 0;
        } else {
            funds -= betAmount;
            return betAmount;
        }
    }

    // Win the bet, add winnings to funds
    void winBet(int betAmount) {
        funds += betAmount;
    }

    // Lose the bet, no money back
    void loseBet(int betAmount) {
        // Nothing to do, as the bet has already been subtracted in placeBet
    }

    // Stand, indicating the player is done with their turn
    void stand() {
        std::cout << name << " stands." << std::endl;
    }

    // Hit, take another card
    void hit() {
        std::cout << name << " hits." << std::endl;
    }

    // Check if the player has busted (score over 21)
    bool hasBusted() const {
        return score > 21;
    }

    // Check if the player has blackjack (exactly 21)
    bool hasBlackjack() const {
        return score == 21 && hand.size() == 2;
    }

    // Update the player's score after adding/removing cards
    void updateScore() {
        score = 0;
        for (const auto& card : hand) {
            score += card.getValue();
        }
    }

    // Get the current number of cards the player has
    size_t getHandSize() const {
        return hand.size();
    }

    // Display player's status
    void displayStatus() const {
        std::cout << "Player: " << name << std::endl;
        std::cout << "Funds: $" << funds << std::endl;
        std::cout << "Score: " << score << std::endl;
    }

    // Display a summary of the player's hand
    void displayHandSummary() const {
        std::cout << name << "'s hand contains " << hand.size() << " cards:" << std::endl;
        for (const auto& card : hand) {
            card.displayCard();  // Assuming you have a Card::displayCard() method for displaying card info
        }
        std::cout << "Total score: " << score << std::endl;
    }

    // Check if the player can still play (has funds left)
    bool canPlay() const {
        return funds > 0;
    }

    // Compare player with another player to see who has the better score
    int compareScores(const Player &other) const {
        if (score > other.score) {
            return 1;  // This player has a higher score
        } else if (score < other.score) {
            return -1; // The other player has a higher score
        } else {
            return 0;  // Scores are equal
        }
    }

    // Transfer funds from one player to another (if they win a bet)
    static void transferFunds(Player &from, Player &to, int amount) {
        from.funds -= amount;
        to.funds += amount;
    }

    // Static method to create a default player (e.g., for AI or dealer)
    static Player createDefaultPlayer() {
        return Player("Dealer", 0);  // Example for a dealer with no initial funds
    }

    // Function to display player details
    void displayPlayerDetails() const {
        std::cout << "Name: " << name << std::endl;
        std::cout << "Funds: $" << funds << std::endl;
        std::cout << "Score: " << score << std::endl;
    }

    // Function to check if the player has reached a specific score threshold (useful for automated games)
    bool hasReachedThreshold(int threshold) const {
        return score >= threshold;
    }

    // Check if the player is eligible for a bonus
    bool isEligibleForBonus() const {
        return score == 21;  // Simple check for blackjack
    }
};

#endif // PLAYER_H
