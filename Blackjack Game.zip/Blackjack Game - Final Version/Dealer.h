#ifndef DEALER_H
#define DEALER_H

#include <iostream>
#include <vector>
#include "Card.h"
#include "Deck.h"

class Dealer {
private:
    std::vector<Card> hand;  // Dealer's hand of cards
    Deck deck;               // Deck of cards used by the dealer
    bool isBusted;           // Track if dealer has busted
    bool hasBlackjack;       // Track if dealer has blackjack
    bool isStanding;         // Track if dealer has decided to stand

public:
    // Constructor initializes the dealer with a new deck
    Dealer();

    // Resets the dealer's hand and the deck for a new round
    void reset();

    // Deals the first two cards to the dealer
    void dealInitialHand(std::vector<Card>& playerHand);

    // Adds a card to the dealer's hand
    void receiveCard(const Card& card);

    // Displays the dealer's hand of cards
    void displayHand(bool showSecondCard = false) const;

    // Calculates the total value of the dealer's hand
    int calculateHandValue() const;

    // Checks if the dealer has busted (hand value > 21)
    bool checkBust() const;

    // Checks if the dealer has blackjack (Ace + 10/Face card)
    bool checkBlackjack() const;

    // Determines if the dealer should hit or stand (dealer stands at 17 or more)
    void playTurn();

    // Returns true if the dealer is busted
    bool isDealerBusted() const;

    // Returns true if the dealer has blackjack
    bool isDealerBlackjack() const;

    // Returns true if the dealer is standing
    bool isDealerStanding() const;

    // Returns the dealer's current hand
    std::vector<Card>& getHand();

    // Shuffles the deck of cards before starting the game
    void shuffleDeck();

    // Deals a card to the player or dealer
    Card dealCard();
};

#endif // DEALER_H
