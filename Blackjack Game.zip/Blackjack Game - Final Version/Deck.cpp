#include "Deck.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

// Constructor to initialize the deck with 52 cards and shuffle
Deck::Deck() : currentCardIndex(0) {
    initializeDeck();
    shuffleDeck();
}

// Initializes the deck with 52 cards (13 ranks x 4 suits)
void Deck::initializeDeck() {
    deck.clear();  // Clear the deck before adding cards

    // Add 13 cards of each suit
    for (int suit = 0; suit < 4; ++suit) {
        for (int rank = 1; rank <= 13; ++rank) {
            deck.push_back(Card(rank, static_cast<Suit>(suit)));  // Adding a new card to deck
        }
    }
    currentCardIndex = 0;  // Reset to the start of the deck
}

// Shuffle the deck randomly using rand()
void Deck::shuffleDeck() {
    // Use current time to seed the random number generator
    std::srand(static_cast<unsigned int>(std::time(0)));

    // Shuffle the deck using a basic shuffle algorithm
    for (int i = deck.size() - 1; i > 0; --i) {  // Ensure size() is used correctly
        int j = std::rand() % (i + 1);  // Random index between 0 and i
        std::swap(deck[i], deck[j]);  // Swap the elements
    }
}

// Deals one card from the deck, advancing the index
Card Deck::dealCard() {
    if (currentCardIndex < deck.size()) {  // Checking if there are still cards
        return deck[currentCardIndex++];
    } else {
        std::cerr << "Deck is empty. Reshuffling..." << std::endl;
        reshuffleDeck();  // Reshuffle and continue dealing if deck is empty
        return dealCard();  // Try dealing again after reshuffling
    }
}

// Returns the number of cards remaining in the deck
int Deck::cardsRemaining() const {
    return deck.size() - currentCardIndex;  // Calculate remaining cards
}

// Resets and reshuffles the deck when the game is over or a new one begins
void Deck::resetDeck() {
    currentCardIndex = 0;
    initializeDeck();
    shuffleDeck();
}

// Display the deck's contents for debugging (or checking)
void Deck::displayDeck() const {
    for (const Card& card : deck) {
        card.displayCard();  // Assuming the Card class has a displayCard function
    }
}

// Checks if the deck is empty (all cards have been dealt)
bool Deck::isEmpty() const {
    return currentCardIndex >= deck.size();  // If current index is equal to or greater than deck size, it's empty
}

// Reshuffles the deck if it is empty
void Deck::reshuffleDeck() {
    if (isEmpty()) {
        resetDeck();  // Reset and reshuffle the deck
    }
}

// Output the current status of the deck (number of remaining cards)
std::ostream& operator<<(std::ostream& os, const Deck& deck) {
    os << "Deck of " << deck.cardsRemaining() << " cards remaining." << std::endl;
    return os;
}
